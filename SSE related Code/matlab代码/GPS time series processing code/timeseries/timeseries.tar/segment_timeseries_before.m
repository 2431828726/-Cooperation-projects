function outser = segment_timeseries_before(inser, t);
%function outser = segment_timeseries_before(inser, t)
% selects the part of the timeseries inser that satisfies the equation:
%   inser.time < t

outser = struct('time', [], 'sitename', [], 'refllh', [], 'refxyz', [], 'llh', [], ...
    'east', [], 'esig', [], 'north', [], 'nsig', [], 'height', [], 'hsig', ...
    [], 'enu', [], 'enucov', []);

i = (inser.time < t);

outser = struct('time', [], 'sitename', [], 'refllh', [], 'refxyz', [], 'llh', [], ...
    'east', [], 'esig', [], 'north', [], 'nsig', [], 'height', [], 'hsig', ...
    [], 'enu', [], 'enucov', []);

outser.sitename = inser.sitename;
outser.refllh   = inser.refllh;
outser.refxyz   = inser.refxyz;

outser.time     = inser.time(i);
outser.llh      = inser.llh(i);
outser.east     = inser.east(i);
outser.esig     = inser.esig(i);
outser.north    = inser.north(i);
outser.nsig     = inser.nsig(i);
outser.height   = inser.height(i);
outser.hsig     = inser.hsig(i);
outser.enu      = inser.enu(i);
outser.enucov   = inser.enucov(i);